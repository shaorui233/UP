function varargout = load_nlpsol(varargin)
    %LOAD_NLPSOL Explicitly load a plugin dynamically.
    %
    %  LOAD_NLPSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(886, varargin{:});
end
