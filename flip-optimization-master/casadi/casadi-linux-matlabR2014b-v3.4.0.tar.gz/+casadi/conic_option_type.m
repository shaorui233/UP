function varargout = conic_option_type(varargin)
    %CONIC_OPTION_TYPE Get type info for a particular option.
    %
    %  char = CONIC_OPTION_TYPE(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(870, varargin{:});
end
