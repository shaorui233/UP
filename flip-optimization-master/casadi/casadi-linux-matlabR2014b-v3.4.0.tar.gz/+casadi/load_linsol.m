function varargout = load_linsol(varargin)
    %LOAD_LINSOL Explicitly load a plugin dynamically.
    %
    %  LOAD_LINSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(914, varargin{:});
end
