function varargout = doc_rootfinder(varargin)
    %DOC_ROOTFINDER Get the documentation string for a plugin.
    %
    %  char = DOC_ROOTFINDER(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(898, varargin{:});
end
