function varargout = is_slice2(varargin)
    %IS_SLICE2 Check if an index vector can be represented more efficiently as two nested
    %
    %  bool = IS_SLICE2([int] v)
    %
    %slices.
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(186, varargin{:});
end
