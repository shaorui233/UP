function varargout = conic_n_out(varargin)
    %CONIC_N_OUT Get the number of QP solver outputs.
    %
    %  int = CONIC_N_OUT()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(868, varargin{:});
end
