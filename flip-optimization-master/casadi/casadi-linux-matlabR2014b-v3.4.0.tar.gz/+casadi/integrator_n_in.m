function varargout = integrator_n_in(varargin)
    %INTEGRATOR_N_IN Get the number of integrator inputs.
    %
    %  int = INTEGRATOR_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(861, varargin{:});
end
