function varargout = load_conic(varargin)
    %LOAD_CONIC Explicitly load a plugin dynamically.
    %
    %  LOAD_CONIC(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(873, varargin{:});
end
