function varargout = has_conic(varargin)
    %HAS_CONIC Check if a particular plugin is available.
    %
    %  bool = HAS_CONIC(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(872, varargin{:});
end
