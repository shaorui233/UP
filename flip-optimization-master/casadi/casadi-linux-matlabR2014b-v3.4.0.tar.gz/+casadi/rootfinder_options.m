function varargout = rootfinder_options(varargin)
    %ROOTFINDER_OPTIONS Get all options for a plugin.
    %
    %  {char} = ROOTFINDER_OPTIONS(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(893, varargin{:});
end
