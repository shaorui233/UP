function varargout = expm_n_in(varargin)
    %EXPM_N_IN Get the number of expm solver inputs.
    %
    %  int = EXPM_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(925, varargin{:});
end
