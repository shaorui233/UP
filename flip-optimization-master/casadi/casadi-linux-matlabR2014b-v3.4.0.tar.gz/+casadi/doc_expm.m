function varargout = doc_expm(varargin)
    %DOC_EXPM Get the documentation string for a plugin.
    %
    %  char = DOC_EXPM(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(929, varargin{:});
end
